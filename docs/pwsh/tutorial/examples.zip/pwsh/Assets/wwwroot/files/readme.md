# Static Assets Readme

These files are served via Kestrun static file service under /assets/files.

Included types:

- .txt
- .md
- .json
- .csv
- .xml
- .yaml
- .png (generated placeholder)
- .docx (minimal OOXML)
- .xlsx (minimal OOXML workbook)
